package com.example.lista3bim


import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


class MainActivity : ComponentActivity() {

    private lateinit var executorCamera: ExecutorService
    private lateinit var visualizacaoCamera: PreviewView
    private lateinit var textoEmoji: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        visualizacaoCamera = findViewById(R.id.cameraPreview)
        textoEmoji = findViewById(R.id.emojiText)

        // Executor para processamento da câmera
        executorCamera = Executors.newSingleThreadExecutor()

        // Permissão da câmera
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            iniciarCamera()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 101)
        }
    }

    private fun iniciarCamera() {
        val provedorCameraFuture = ProcessCameraProvider.getInstance(this)

        provedorCameraFuture.addListener({
            val provedorCamera = provedorCameraFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(visualizacaoCamera.surfaceProvider)
            }

            val analiseImagem = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(executorCamera) { imagemProxy ->
                        processarImagem(imagemProxy)
                    }
                }

            try {
                provedorCamera.unbindAll()
                provedorCamera.bindToLifecycle(
                    this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analiseImagem
                )
            } catch (erro: Exception) {
                Log.e("Camera", "Erro ao iniciar câmera", erro)
            }

        }, ContextCompat.getMainExecutor(this))
    }

    private fun processarImagem(imagemProxy: ImageProxy) {
        val imagemMedia = imagemProxy.image
        if (imagemMedia != null) {
            val imagem = InputImage.fromMediaImage(imagemMedia, imagemProxy.imageInfo.rotationDegrees)

            // Configuração do detector de faces
            val opcoes = FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .build()

            val detector = FaceDetection.getClient(opcoes)

            detector.process(imagem)
                .addOnSuccessListener { rostos ->
                    if (rostos.isNotEmpty()) {
                        val rosto = rostos[0] // pega o primeiro rosto

                        val probSorriso = rosto.smilingProbability ?: -1f

                        val emoji = when {
                            probSorriso > 0.6 -> "😄" // feliz
                            probSorriso < 0.3 -> "😐" // neutro
                            else -> "😮" // surpresa
                        }

                        runOnUiThread {
                            textoEmoji.text = emoji
                        }
                    }
                }
                .addOnFailureListener { erro ->
                    Log.e("MLKit", "Erro: ${erro.message}")
                }
                .addOnCompleteListener {
                    imagemProxy.close()
                }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executorCamera.shutdown()
    }
}
